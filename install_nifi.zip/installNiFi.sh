#!/bin/bash
#NIFI_VERSION=1.11.4
#INSTALL_DIR=/tmp/nifi
#CERT_DIR=/tmp/nifi/certs
#KEYSTORE_PASSWORD=keyPasswd
#TRUSTSTORE_PASSWORD=trustPasswd
source ./settings.txt

mkdir ${INSTALL_DIR}
mkdir ${CERT_DIR}
./createKey.sh keystore ks@#Xjk123
./createKey.sh admin admin@#Xjk123
./createKey.sh dev dev@#Xjk123

wget -O ${INSTALL_DIR}/nifi-${NIFI_VERSION}-bin.tar.gz http://mirror.cc.columbia.edu/pub/software/apache/nifi/${NIFI_VERSION}/nifi-${NIFI_VERSION}-bin.tar.gz
tar -xvf ${INSTALL_DIR}/nifi-${NIFI_VERSION}-bin.tar.gz -C ${INSTALL_DIR}
tar -xvf ${INSTALL_DIR}/demo.tar -C ${INSTALL_DIR}/nifi-${NIFI_VERSION}

rm ${INSTALL_DIR}/nifi-${NIFI_VERSION}-bin.tar.gz

./updateNiFiProperties.sh
cp ${CERT_DIR}/*p12 ${INSTALL_DIR}/nifi-${NIFI_VERSION}/ 
